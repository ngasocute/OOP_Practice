package hust.soict.globalict.aims.media;

public interface Playable {
    public void play();
}
