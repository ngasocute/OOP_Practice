package hust.soict.globalict.test.disc;

public class TestingParameter {
}
