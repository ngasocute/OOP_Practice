public interface Comparable {
    
}
